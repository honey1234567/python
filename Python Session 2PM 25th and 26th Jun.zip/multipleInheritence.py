class a:
    def add(s,a,b):
        c =a+b
        print'sum of two num :',c

    def mul(s,a,b):
        c =a*b
        print 'mul of two num- CLASS A :',c


class b:

    def sub(s,a,b):
        c =a-b
        print 'sub of two num :',c
        
    def mul(s,a,b):
        c =a*b
        print 'mul of two numbers CLASS-B',c


class compute(a,b): # multiple inheritence

        def dev(s,a,b):
            c =a/b
            print c
            

########
o = compute()
o.add(11,2)
o.sub(11,2)
o.dev(11,2)
o.mul(11,2)









    
    
    


