class a:
    def wel(s):
        print 'welcome structual programing !!!'

    def add(s,a,b):
        c =a+b
        print c

class b(a):

    def wel(s):
        print 'welcome structual programing with oops conscept !!!'

    def sub(s,a,b):
        c =a-b
        print c


o =b()
o.wel()
o.add(11,2)
o.sub(44,5)


        
