n =0
d = 0

while True:
        
    try:
        n =input('enter data :')
        d =input('enter divisor :')

        if d<0:
            er = ZeroDivisionError('divisor cannot be less than 0')
            raise er
        
        o = n/d
        print o
        break         
    except ZeroDivisionError as err:
        print err
    except NameError as err:
        
        print err
    except: # handle/catch any types of error 
        print 'there is some techincal error'
    finally:
        print 'end of try block'
        
o =n+d
print 'sum of two numbers ',o
