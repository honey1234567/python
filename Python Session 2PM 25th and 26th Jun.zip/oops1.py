#create class
class emp:

        #function 
        def newEmp(s):
            print s
            #local variable
            a =1

            #to make global variable 
            s.eid =1
            s.name = 'nitin'
        def showEmp(a):
            print a
            print 'employee id :',a.eid
            print 'employee name :',a.name

        def __init__(self,msg):
            print self ,' is created '
            print msg
            self.eid = 0
            self.name ='default'
            
        def __del__(s):
             print s,'is removed'

#create object
e = emp('new object')

           
e.showEmp()
print e
e.newEmp()
e.showEmp()

del e

#will throw error
#e.showEmp()




    
