s = raw_input('enter string :')

l = list(s)
for c in l:
    print ord(c)
    
    
