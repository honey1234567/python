class calc: # parent class

    def add(s,a,b):
        c =a+b
        print c


#child class
class dcalc(calc):  # extend class clac to class dcalc 
    def mul(self,a,b):
        c =a*b
        print(c)

#class  tax
class tax(calc):
    def computeTax(s,amt):
        if amt<300000:
            print 'no tax'
        
        else:
            print 'taxable income'



            

##create
        
o = dcalc() ### child class object can access parent class method
o.add(1,2)
o.mul(1,2)

t =tax()
t.add(11,2)
#t.mul(11,2)
t.computeTax(1122300)







