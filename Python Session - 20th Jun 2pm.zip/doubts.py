#convert list to string
#print without space

l = ['a','b','c','d']
print(l)

w = ''
for x in l:
     w =w+x
print(w)

##slicer
name = 'nitin sharma'
########01234567891011
print(name[2:5])
print(name[0:5])
print(name[:5])
print(name[:])
print(name[::-1]) # -1 reverse

## trim : remove extra spa e
name = '   raman sinha '
l = len(name)  # return count of chars including space
print(l)
name  = name.strip()
l = len(name)

print (l)


## pattern
name="RAJAT"
l = list(name)
print(l)

s = ''
for x in l:
     s =s+x
     print(s)


###
for i in range(0,len(l)):
     for c in range(0,i+1):
          print (l[c],end='')
     print()

for i in range(4,-1,-1):
     for c in range(0,i+1):
          print (l[c],end='')
     print()


     
     
          
     



















     
     
     
