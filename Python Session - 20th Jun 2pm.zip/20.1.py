#program to read a pRTICULAR WORD count

f = open(r'C:\Users\mihir\Desktop\output.txt','r')
wc=0
word=raw_input('enter word  for which you want to get count:')
list=f.readlines()
for x in list:
    w=x.split(' ')
    for i in w:
        if word == i:
               wc=wc+1
print 'the count of'+' word '+' is ',wc
f.close()
               
