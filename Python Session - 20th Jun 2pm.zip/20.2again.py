str=raw_input('enter string:')
l=list(str)
#print len(l)equal to length of str
found1=False
for i in range(0,len(str)):

    if found1==False and l[i]!=' ':
        l[i]=l[i].upper()
	found1=True 
    elif l[i]== ' ':
	found1=False
w = ''
for x in l:
     w =w+x
print w	

    
    

    




    
    

    
