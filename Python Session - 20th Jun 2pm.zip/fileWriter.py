
#f = open(r'C:\Users\vkumar15\Desktop\output.txt','w') # create new file

f = open(r'C:\Users\vkumar15\Desktop\output.txt','a') # open the file in append mode



f.write('Welcoem to ...\n')
f.write('hellow world\n')

f.close()#absence of it will make the data hidden on pressing f5 bt after its presence and again execution will make the data to be written two times




##open file in append mode and write dynamic data

f = open(r'C:\Users\vkumar15\Desktop\output.txt','a') # open the file in append mode

while True:
     op = input('enter 1 for add 2. for exit ')
     if op == '1':
          row = input('enter data which you want to store  :')
          f.write(row)
          f.write('\n')
     elif op =='2':
          f.close()
          print('data is saved ')
          break
     else:
          print('invalid choice !!!')

          
     





     
     


          
          
