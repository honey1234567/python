i =1  # init 
s =''

while i<=10: # condition

    #print  i,
    s = s+str(i)
    i =i+1
print s

## print in reverse 
i =10 # init 
while i>0:  #condition 
    print i,
    i =i-1


######
n1 = input('enter start no. :') # 5
n2 = input('enter end no. :') # 100

while n1<=n2:
    print n1,
    n1=n1+1
    
