marks = [66,77,88,99,55,66,77]
print marks 

# print by index
print marks[1] # 2nd element 

## print all elements by index / loop
for x in marks:
    print x

## or 
for i in range(0,len(marks)):
    print marks[i]    

## len : size of list
print 'count of elements :', len(marks)    

## max  : return highest value
print  'max = ',max(marks)

## min  : return lowes value
print  'min = ',min(marks)


## sum  : return total
print  'total = ',sum(marks)

## append : add new value after last index
marks.append(100)
marks.append(770)
marks.append(80)

print marks 

## pop : remove last value 
print marks.pop() 
print marks 

## insert : add new element at given position 
marks.insert(1,44)
print marks

### remove : remove element by value 
marks.remove(44)
print marks 

## sort : arrange data in ascending order
marks.sort()
print marks 

# print in descending 
print marks[::-1]
