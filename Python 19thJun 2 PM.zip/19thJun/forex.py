for i in range(1,101):
    print i,

###print all odd numbers betwen two given range
n1 = input('enter start no. ') #2
n2 = input('enter last no. ')#100

'''
if n1%2 == 0:
    n1=n1+1
for i in range(n1,n2+1,2):
    print i,
'''

### or
for i in range(n1,n2+1,1):
    if i%2 != 0:
        print i,

##print in reverse
for i in range(10,0,-1):    # init, condition<, steps
        print i, 
