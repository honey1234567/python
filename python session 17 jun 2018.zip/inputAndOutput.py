# input / output
ids =  input('enter id :')
name = raw_input('enter name :')

print ids,
print name
