#23
'''
id = input('Enter Employee Code: ')
name = input('Enter Name: ')
salary = input('Enter Salary: ')

print id
print name
print salary

hra = salary*0.4
da = salary*0.1
cca = salary*0.05
gs = salary+hra+da+cca
pf = gs*0.1
it = gs*0.1
ns = gs-(pf+it)

print hra
print da
print cca
print gs
print pf
print it
print ns
'''

#B8
'''
salary = input('Enter Salary: ')

if salary in range(5000,10001):
    hra = salary*0.1
    da = salary*0.05
    print hra
    print da
    
elif salary in range(10000,15001):
    hra = salary*0.15
    da = salary*0.08
    print hra
    print da

else:
    print 'invalid value'
'''

#B9
'''
a=input('Enter marks: ')
b=input('Enter marks: ')
c=input('Enter marks: ')
d=input('Enter marks: ')
e=input('Enter marks: ')

total = a+b+c+d+e
per = (total/5)

if per in range(60,101):
    print 'First Division'
    print per

elif per in range(50,60):
    print 'Second Division'
    print per

elif per in range(40,50):
    print 'Third Division'
    print per

else:
    print 'Fail'
    print per
'''

#B10
'''
unit=input('Enter units consumed: ')
fixed=50

if unit in range (0,101):
    bill=(unit*0.4)+50
    print bill

elif unit in range (101,301):
    bill = (unit*0.5)+50
    print bill

else:
    bill = (unit*0.6)+50
    print bill
'''

#B31
'''
i = 51
for i in range (51,91):
    print i
    i = i+1
'''

#B33
'''
a=input('Enter first number: ')
b=input('Enter second number: ')

if b<a:
    print 'Second number needs to be higher'

else:
    for i in range (a,b):
        print i
        i = i+1
'''
#B34
'''
for i in range (1,50,2):
    i = i+1
    print i
'''

#B35
'''
for i in range (1,50,2):
    print i
'''

#B39
'''
a= input('Enter a number: ')
for i in range (1,11):
    i = i*a
    print i
'''
#B32
'''
a= input ('enter start no. ')
b=input('enter last no. ')

s = 0
for i in range(a,b+1,):
    s = s+i

print s
'''

#B36
'''
a=input('Enter a number: ')
s = 0
for i in range(1,a):
    s = s+i
print s
avg = s/a
print avg
'''

#B37
'''
a=input('Enter a number: ')
s = 0
for i in range(1,a,2):
    s = s+i
print s
avg = s/a
print avg
'''

#B38
'''
a=input('Enter a number: ')
s = 0
for i in range(0,a,2):
    s = s+i
print s
avg = s/a
print avg
'''

#B76 (1)
a=2
print a
for i in range (1,129):
    i = (i+1)*2
    s=i
    print s
