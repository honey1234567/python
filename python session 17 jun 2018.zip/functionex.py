'''
function: is set of comamnd or instructions
---------------------------------------------------------
function can be user defined:
-reusability of code
-support to modular approach
-easy to manage the source code


There are following types of functions:
-no argument no return
-no argument with return
-argument with no return
-argument with return

Module: is seperate file or set of functions, class which can import and load in another program 
---------------------------------------------------------
import filename

from filename import functionname,fun2


exception handling: to handle runtime error
-------------------------- -------------------------
-prevent the project from failure due to single error
-customization of error message

try:


except:/catch  


file handling:
-------------------------
open()
mode:
        r
        w
        a+
        w+
        




            



'''
# no argument no return
def welcome():
    print('welcome to fun world....')

#no argument with return
def getNum():
    n =100
    return n

#argument with no return
def sumNum(a,b):
    c = a+b
    print(c)

#argument with return
def subNum(a,b):
    c = a-b
    return c

def test(a):
    for d in a:
        print(d)    
   


welcome()
welcome()
o = getNum()
print(o+100)
sumNum(111,22)
o = subNum(11,2)
print(o)

test([22,333,4544434,3333])


flag = 1
while flag == 1:
    
    try:
        a = input('enter num :')
        b = input('enter num :')

        c = a+b
        print(c)
        
        flag = 0
        
    except:
        print('invalid input')
        flag = 1

    

print('thankyou ..')
      
    

f = open(r'C:\Users\Vimlesh\Desktop\data\ABC.txt','r')

#print(f.read()) # entire file as a text

#d = f.readlines()# entire file and convert to array
#print(d)

print(f.readline()) # first row

f.close()


f = open(r'C:\Users\Vimlesh\Desktop\data\ABC1.txt','w')
f.write("dajakhs s \n skshsjg ")
f.close()















