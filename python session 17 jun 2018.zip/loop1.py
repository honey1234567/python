'''
#while looop
i =1#init
while i<5: #condition 
    print(i)
    i = i+1 # increment

print '------------------------'
# while - print in reverse order
i =10
while i>0:
    print i
    i=i-1

#print all odd numbers between 1 to 123
i =1
while i<=123:
    print i
    i = i+2

#table of 9
i =1
while i<=10:
    print i*9
    i = i+1

#
i = 9
while i<=90:
    print i
    i = i+9


##### for
for i in range(1,11):
    print i

#in rerverse
for i in range(10,0,-1):
    print i
'''

###nested loop: loop inside loop
# r1 , c1 c2 c3 c4
#r2 , c1 c2 c3 c4
#r3, c1 c2 c3 c4
#r4, c1 c2 c3 c4

r = 1
while r<3:     #row 
    c =1     #col 
    while c<3:
        #print r,c
        c = c+1
        
    r=r+1


r = 1
while r<8:     #row 
    c =1     #col
    s = ''
    while c<5:
        s = s +str(r)+str(c)+'\t'
        c = c+1
        
    print s
    r=r+1
    
################


r = 1
while r<5:     #row 
    c =1     #col
    s = ''
    while c<5:
        s = s +'* '
        c = c+1
        
    print s
    r=r+1

######

r = 1
while r<5:     #row 
    c =1     #col
    s = ''
    while c<=r:
        s = s +'* '
        c = c+1
        
    print s
    r=r+1

######

r = 1
while r<5:     #row 
    c =r     #col
    s = ''
    while c<5:
        s = s +'* '
        c = c+1
        
    print s
    r = r+1


##########
for r in range(1,5):
    s = ''
    for c in range(r,5):
        s= s+ '* '
    print s



########## string data

name =input('enter name : ')

print(name)
print name[0]
print name[0:4]  # slicer 
print name[-1]

print len(name)

s =''
for i in range(len(name)-1,-1,-1):
    s = s+name[i]
    
print s


a = list(name)
print a













    

        
        


    










