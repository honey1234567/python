##int 
a = 1
print type(a)

#float
a = 1.22
print type(a)

#str
a = 'a1'
print type(a)

#bool
a = True
print type(a)

#list
a = [11,1,2,222,'fff']
print type(a)

#tuple
a = (11,1,2,222,'fff')
print type(a)

#dict
a = {'a':'alpha','b':'beta'}
print type(a)


#set 
a = {'item1','item2','item1'}
print type(a)








