n = input('enter data : ')


a                   =           raw_input('enter name : ')
print 'you have entered : ',n,
print 'you have entered : ',a

#in 3.0 or above 
#print ('you have entered : ',n,end=',')
#print ('you have entered : ',a)

a =1
b =2
c =3
name ='sjsgjs sg'
print 'msg = ',a,' msg  = ',b,' msg = ',c,name ,len(name)+a
