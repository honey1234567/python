i =1  # init 
while i<10:  # condition 
    print i,
    i =i+1  # increment 

print 
#print in reverse order
i =10
while i>0:
    print i,
    i =i-1


print 
## print all odd numbers between 1 to 100
i =1
while i<100:
    print i,
    i =i+2


### wap to get the sum all even and odd numbers between two given range
n1= input('start no .:')
n2= input('to no .:')
so = 0
se = 0

while n1<=n2:
    if n1%2==0:
        se =se+n1
    else:
        so = so+n1
    n1=n1+1

print 'sum of all even no : ',se
print 'sum of all odd no : ',so


###for 
for x in range(1,100):# 1 to 99, default increment is 1
    print x,